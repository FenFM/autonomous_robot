#define bool  int
#define TRUE  1
#define FALSE 0

#define int32 long
#define u_int16 unsigned
#define int16 int
