struct UserInfo *SetUserInfo()
{
  struct UserInfo *user_info;

  user_info = (struct UserInfo *)malloc(sizeof(struct UserInfo));
  user_info->Info     = NUMBER_OF_INFO;
  user_info->Pages[0] = PAGES_INFO_1;
  user_info->Pages[1] = PAGES_INFO_2;
  user_info->Pages[2] = PAGES_INFO_3;
  user_info->Pages[3] = PAGES_INFO_4;
  strcpy(user_info->Title[0],TITLE_INFO_1);
  strcpy(user_info->Title[1],TITLE_INFO_2);
  strcpy(user_info->Title[2],TITLE_INFO_3);
  strcpy(user_info->Title[3],TITLE_INFO_4);
  return(user_info);
}
